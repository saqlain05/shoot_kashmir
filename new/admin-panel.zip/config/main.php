<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$title="Shoot Kashmir || Kashmir's Largest Film Production Company";
$address_line1 = "123 Main Street";
$address_line2 = "New York, NY 10001";


$facebook ="http://www.facebook.com";
$youtube = "http://www.youtube.com";