<?php
$conn=mysqli_connect("localhost","wwwshoot_k_shootkashmir","N7eP0CCSKI2x","wwwshoot_kasmir_records");
if(!$conn){
	echo "Database not connect"."<br>";
}

?>